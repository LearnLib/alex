# Start ToDo

* Execute `java -jar ./jetty-runner.jar --port XXXX ./Todo-App.war`
* Open `http://localhost:XXXX` in a web browser
